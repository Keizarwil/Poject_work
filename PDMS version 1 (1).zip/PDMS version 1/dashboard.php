<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  // Redirect the user to the login page
  header('Location: login.php');
  exit;
}

// Show the dashboard content
// echo 'Welcome to the dashboard';
?>
<html>
  <head>
    <Title>dashboard</Title>
    <link rel="stylesheet"  href="style.css">
  </head>
  <body>
    
  </body>
</html>