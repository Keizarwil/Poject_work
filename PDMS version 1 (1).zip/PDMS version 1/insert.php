<?php  
 $connect = mysqli_connect("localhost", "root", "", "pdms");  
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $name = mysqli_real_escape_string($connect, $_POST["name"]);  
      $address = mysqli_real_escape_string($connect, $_POST["address"]);  
      $gender = mysqli_real_escape_string($connect, $_POST["gender"]);  
      $designation = mysqli_real_escape_string($connect, $_POST["designation"]);  
      $age = mysqli_real_escape_string($connect, $_POST["age"]);  
      if($_POST["employee_id"] != '')  
      {  
           $query = "  UPDATE patient SET Firstname='$name', Lastname='$address', Gender='$gender', Address = '$designation',   
           issue = '$age'   
           WHERE ID='".$_POST["employee_id"]."'";  
           $message = 'Data Updated';
      }  
      else  
      {  
           $query = "INSERT INTO patient(Firstname, Lastname, gender, Address, issue)VALUES('$name', '$address', '$gender', '$designation', '$age'); ";  
           $message = 'Data Inserted';  
      }  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM patient ORDER BY ID DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th >First Name</th>  
                          <th >Last Name</th> 
                          <th >contact</th> 
                          <th >Address</th> 
                          <th >issue</th> 
                          <th ></th>  
                           
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["Firstname"] . '</td>  
                          <td>' . $row["Lastname"] . '</td>
                          <td>' . $row["contact"] . '</td>
                          <td>' . $row["Address"] . '</td>
                          <td>' . $row["issue"] . '</td>
                          <td><input type="button" name="edit" value="Edit" id="'.$row["ID"] .'" class="btn btn-info btn-xs edit_data" /></td>  
                            
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
      }  
      echo $output;  
 }  
 ?>
 