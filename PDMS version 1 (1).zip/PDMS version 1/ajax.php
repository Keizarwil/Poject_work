

<!DOCTYPE html>
<html>
<head>
    <title>Search Form</title>
    <style>
        form {
            border: 1px solid #ccc;
            padding: 20px;
            width: 300px;
            margin: 0 auto;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type=text] {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type=submit] {
            background-color: #839192;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
            font-size: 16px;
        }
        input[type=submit]:hover {
            background-color: #45a049;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            text-align: left;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #839192;
            color: white;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .no-results {
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
    <script>
        function searchRecords() {
            var first_name = document.getElementById('first_name').value;
            var last_name = document.getElementById('last_name').value;

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById('result').innerHTML = this.responseText;
                }
            };
            xhr.open('POST', 'search1.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send('first_name=' + first_name + '&last_name=' + last_name);
        }
    </script>
</head>
<body>
    <!-- -----------------edit------------ -->
    <div id="modal">
  <div class="modal-content">
    <span class="close" onclick="hideModal()">&times;</span>
    <h2 style="Text-align:center">Add prescription</h2>
    <form id="update-form" method="post" action="searchpost.php">
        <div style="display:flex">
        <div>
      <label for="name"><b>Firstname:</b></label><br>
      <input type="text" name="fname" id="fname" style="width:200px">
      <br>
    </div>
    <div style="margin-left:20px">
      <label for="lname"><b>Lastname:</b></label><br>
      <input type="text" name="lname" id="lname" script="height:3px" style="width:200px"><br>
    </div>
    </div>
      <label for="contact"><b>contact:</b></label><br>
      <input type="text" name="contact" id="contact"><br>
      <label for="prescription"><b>Prescription:</b></label><br>
      <input type="text" name="prescription" id="prescription"><br>
      
      <input type="submit" value="Save" id="submit" style="background-color:green; outline:none; border: none;
       color: white; padding:5px;border-radius:5px;cursor:pointer";>
    </form>
  </div>
</div>
    <!-- -----------------edit------------ -->
    <form>
        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name" onkeyup="searchRecords()">
        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" onkeyup="searchRecords()">
    </form>
    <div id="result"></div>

    <!-- -----------------edit------------ -->
    <script>
    function showModal() {
  // Show the modal
  document.getElementById("modal").style.display = "block";
}

function hideModal() {
  // Hide the modal
  document.getElementById("modal").style.display = "none";
}

function submitForm(event) {
  // Prevent the default form submission behavior
  event.preventDefault();

  // Get the form data
  var formData = new FormData(document.getElementById("update-form"));

  // Create an XMLHttpRequest object
  var xhr = new XMLHttpRequest();

  // Define the function to be called when the response is received
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      // Get the response from the server
      var response = xhr.responseText;

      // Hide the modal
      hideModal();
    }
  };

  // Send a request to the PHP script to update the user information
  xhr.open("POST", "update.php", true);
  xhr.send(formData);
}

// Add an event listener to the form submit button
document.getElementById("update-form").addEventListener("submit", submitForm);

</script>
<script>
  const form = document.querySelector('form');
  const submitBtn = document.querySelector('#submit');

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(form);

    fetch(form.action, {
      method: form.method,
      body: formData
    })
    .then(response => {
      if (response.ok) {
        showToast('success', 'Data captured successfully');
        form.reset();
      } else {
        showToast('error', 'Error adding data');
      }
    })
    .catch(error => {
      showToast('error', 'Error adding data');
    });
  });

  function showToast(type, message) {
    const toast = document.createElement('div');
    toast.classList.add('toast', `toast-${type}`);
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3000);
  }
</script>
    <!-- -----------------edit------------ -->
</body>
</html>
<!-- -----------------edit------------ -->
<style>
#modal {
  display: none;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.5);
  
}

/* Style the modal content */
.modal-content {
  background-color: white;
  margin: 10% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 50%;
  height: 60%;
  animation-name: slide-in;
  animation-duration: 0.5s;
  animation-fill-mode: forwards;
  transform: translateY(-100%);
}
@keyframes slide-in {
  from {
    transform: translateY(-100%);
  }
  to {
    transform: translateY(0);
  }
}

/* Style the close button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
input[type="text"]
   {
    width: 60%;
    padding: 10px;
    margin-bottom: 20px;
    border: none;
    border-radius: 5px;
    box-shadow: 0 0 5px #ccc;
  }
  #update-form{
    margin-left: 30px;
    width:460px;
  }
  /* -------------------- */
  .toast {
    position: fixed;
    top: 10px;
    left: 50%;
    transform: translateX(-50%);
    padding: 10px 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    color: #fff;
    font-size: 14px;
    z-index: 9999;
    opacity: 0;
    animation: fadeIn 0.5s forwards, fadeOut 0.5s 2.5s forwards;
  }
  
  .toast-success {
    background-color: green;
  }
  
  .toast-error {
    background-color: red;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  @keyframes fadeOut {
    from { opacity: 1; }
    to { opacity: 0; }
  }
  </style>