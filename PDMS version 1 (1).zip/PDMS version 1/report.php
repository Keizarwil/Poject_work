<?php
session_start();

// establish a database connection
$host = "localhost"; // or your database host
$username = "root"; // or your database username
$password = ""; // or your database password
$dbname = "pdms"; // replace with your actual database name

$conn = mysqli_connect($host, $username, $password, $dbname);

// check if the connection was successful
if(!$conn){
  die("Database connection failed: " . mysqli_connect_error());
}

// check if the doctor is logged in
if(!isset($_SESSION['username'])){
  echo "You need to login first.";
  header('Location:login.php');
  exit;
}

// retrieve the doctor's username from the session
$username = $_SESSION['username'];

// query the database for the doctor's prescriptions
$query = "SELECT * FROM prescription WHERE prescribed_by = '$username'";
$result = mysqli_query($conn, $query);
?>
<div class="tbg">
<?php
// generate the report as a styled table with a pleasing appearance
if(mysqli_num_rows($result) > 0){
  
  echo "<table class='styled-table'>";
  echo "<thead><tr><th>First name</th><th>Last name</th><th>Contact</th><th>Prescription Date</th><th>Medication</th><th>Doctor's name</th></tr></thead>";
  echo "<tbody>";
  while($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
    echo "<td>".$row['Firstname']."</td>";
    echo "<td>".$row['Lastname']."</td>";
    echo "<td>".$row['contact']."</td>";
    echo "<td>".$row['date']."</td>";
    echo "<td>".$row['prescription']."</td>";
    echo "<td>".$row['prescribed_by']."</td>";
    echo "</tr>";
  }
  echo "</tbody></table>";
  
} else {
  echo "No prescriptions found for the logged in doctor.";
}
?>
</div>
<style>
.styled-table {
  width: 98%;
  border-collapse: collapse;
  margin: 25px 0;
  font-size: 0.9em;
  font-family: sans-serif;
  min-width: 400px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.30);  
  border-top-left-radius: 10px;
  border-top-right-radius: 10px; 
  background-color: white;
  margin-left: 10px;
  padding-top: 10px;
}

.styled-table thead tr {
  background-color: #BFC9CA;
  color: black;
  text-align: left;
}

.styled-table th,
.styled-table td {
  padding: 12px 15px;
}

.styled-table tbody tr {
  border-bottom: 1px solid #dddddd;
}

.styled-table tbody tr:nth-of-type(even) {
  background-color: #f3f3f3;
}

.styled-table tbody tr:last-of-type {
  border-bottom: 2px solid #95A5A6;
}

.styled-table tbody tr.active-row {
  font-weight: bold;
  color: #009879;
}
.tbg{
  background-color: #EAECEE;
  border-radius: 10px;
  height: 100%;
  margin-top: 0;
  padding-top: 2px;
}

</style>
