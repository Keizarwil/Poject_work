<?php  
 if(isset($_POST["employee_id"]))  
 {  
      $output = '';  
      $connect = mysqli_connect("localhost", "root", "", "pdms");  
      $query = "SELECT * FROM patient WHERE ID = '".$_POST["employee_id"]."'";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>FName</label></td>  
                     <td width="70%">'.$row["Firstname"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Lname</label></td>  
                     <td width="70%">'.$row["Lastname"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Gender</label></td>  
                     <td width="70%">'.$row["Gender"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Address</label></td>  
                     <td width="70%">'.$row["Address"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>issue</label></td>  
                     <td width="70%">'.$row["issue"].' Year</td>  
                </tr>  
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>