<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pdms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
if(isset($_POST['fname'])){
  
  $Firstname = trim(htmlspecialchars($_POST['fname']));
  $Lastname = trim(htmlspecialchars($_POST['lname']));
  $gender = trim(htmlspecialchars($_POST['gender']));
  $DOB = trim(htmlspecialchars($_POST['DOB']));
  $Contact = trim(htmlspecialchars($_POST['contact']));
  $Address = trim(htmlspecialchars($_POST['Address']));
  $issue = trim(htmlspecialchars($_POST['issue']));

$sanitized_fname = mysqli_real_escape_string($conn, $Firstname);
$sanitized_lname = mysqli_real_escape_string($conn, $Lastname);
$sanitized_contact = mysqli_real_escape_string($conn, $Contact);
$sanitized_Address = mysqli_real_escape_string($conn, $Address);
$sanitized_issue = mysqli_real_escape_string($conn, $issue);

// Insert data into database
$sql = "INSERT INTO patient (Firstname, Lastname, Gender, DOB, contact, Address, issue) 
VALUES ('$sanitized_fname', '$sanitized_lname', '$gender', '$DOB', '$sanitized_contact', '$sanitized_Address', '$sanitized_issue')";

if ($conn->query($sql) == TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

}


$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data entry</title>
    <link rel="stylesheet" href="entry.css">
  </head>
  <body>
	<h3><b>Patient Details</b></h3>
  <form action="data entry.php" method="POST">
        <div class="main">
         <div class="left">
        <label for="fname">First name</label><br>
        <input type="text" name="fname" id="fname" required pattern="^[A-Za-z][A-Za-z]{3,20}$">
        <div id="fname-error" style="color:red; font-size:small" ></div>
        <div id="my-fname-error" style="color:red; font-size:small" ></div>
        <br><br>
        <label for="lname">Last name</label><br>
        <input type="text" name="lname" id="lname" required pattern="^[A-Za-z][A-Za-z]{3,20}$">
        <div id="lname-error" style="color:red; font-size:small" ></div>
        <div id="my-lname-error" style="color:red; font-size:small" ></div>
        <br><br>
        <label for="gender">Gender</label><br>
        <select name="gender" id="gender">
        <option value="male">Male</option>
        <option value="female">Female</option>
       </select><br>
       </div>
       <div class="right">
       <label for="DOB">Date of birth</label><br>
       <input type="date" name="DOB" id="DOB" required><br><br><br>
       <label for="contact">Contact</label><br>
       <input type="tel" name="contact" id="contact" required ><br><br><br>
       <label for="Address">Address</label><br>
       <input type="text" name="Address" id="Address" required pattern="^[A-Za-z][A-Za-z0-9_]{4,29}$">
       <div id="address-error" style="color:red; font-size:small"></div>
       <div id="my-address-error" style="color:red; font-size:small" ></div>
       <br>
       </div>
       </div><br><br>
       <label for="issue">Health issue</label><br>
       <textarea id="issue" name="issue" rows="4" cols="50" required pattern="^[A-Za-z][A-Za-z0-9_]{5,30}$"></textarea>
       <div id="issue-error" style="color:red; font-size:small"></div>
       <div id="my-issue-error" style="color:red; font-size:small" ></div>
       <br><br>
       
       <button type="submit" id="submit" name="submit">Submit</button>
       </form>
       
       <script>
        const fnameInput = document.getElementById("fname");
        const lnameInput = document.getElementById("lname");
        const addressInput = document.getElementById("Address");
        const issueInput = document.getElementById("issue");
        const fnameError = document.getElementById("fname-error");
        const lnameError = document.getElementById("lname-error");
        const addressError = document.getElementById("address-error");
        const issueError = document.getElementById("issue-error");
        const usernamePattern = /^[A-Za-z][A-Za-z]/; // regular expression pattern for username
        const addressPattern = /^[A-Za-z][A-Za-z0-9_]{4,29}$/; // regular expression pattern for address
        const issuePattern = /^[A-Za-z][A-Za-z0-9_]{5,30}$/; // regular expression pattern for Health issue

        fnameInput.addEventListener("input", function() {
          if (!fnameInput.value) { // check if input is empty
            fnameError.textContent = ""; // clear error message if input is empty
          }else if (!usernamePattern.test(fnameInput.value)) { // check if input matches pattern
          fnameError.textContent = "Invalid name format"; // set error message
          }else {
            fnameError.textContent = ""; // clear error message if input is valid
          }

          });

        lnameInput.addEventListener("input", function() {
          if (!lnameInput.value) { // check if input is empty
            lnameError.textContent = ""; // clear error message if input is empty
          }else if (!usernamePattern.test(lnameInput.value)) { // check if input matches pattern
          lnameError.textContent = "Invalid name format"; // set error message
          } else {
            lnameError.textContent = ""; // clear error message if input is valid
          }

          });

          addressInput.addEventListener("input", function() {
          if (!addressInput.value) { // check if input is empty
            addressError.textContent = ""; // clear error message if input is empty
          }else if (!addressPattern.test(addressInput.value)) { // check if input matches pattern
          addressError.textContent = "Wrong address format"; // set error message
          } else {
            addressError.textContent = ""; // clear error message if input is valid
          }
          });

          issueInput.addEventListener("input", function() {
          if (!issueInput.value) { // check if input is empty
            issueError.textContent = ""; // clear error message if input is empty
          }else if (!issuePattern.test(issueInput.value)) { // check if input matches pattern
          issueError.textContent = "Wrong format"; // set error message
          } else {
            issueError.textContent = ""; // clear error message if input is valid
          }
          });

      </script>
      <!-- javascript for length checking -->
       <!-- ---------------- -->
       <script>
        const myFnameInput = document.getElementById("fname");
        const myLnameInput = document.getElementById("lname");
        const myAddressInput = document.getElementById("Address");
        const myIssueInput = document.getElementById("issue");
        const myFnameError = document.getElementById("my-fname-error");
        const myLnameError = document.getElementById("my-lname-error");
        const myAddressError = document.getElementById("my-address-error");
        const myIssueError = document.getElementById("my-issue-error");

        myFnameInput.addEventListener("input", function() {
          if (!myFnameInput.value) { // check if input is empty
            myFnameError.textContent = ""; // clear error message if input is empty
          }else if (myFnameInput.value.length < 3) {
         myFnameError.textContent = "Input must be at least 3 characters long";
        myFnameError.style.color = "red";
        } else {
          myFnameError.textContent = "";
         myFnameError.style.color = "initial";
        }
        });

        myLnameInput.addEventListener("input", function() {
          if (!myLnameInput.value) { // check if input is empty
            myLnameError.textContent = ""; // clear error message if input is empty
          }else if (myLnameInput.value.length < 3) {
         myLnameError.textContent = "Input must be at least 3 characters long";
        myLnameError.style.color = "red";
        } else {
          myLnameError.textContent = "";
         myLnameError.style.color = "initial";
        }
        });

        myAddressInput.addEventListener("input", function() {
          if (!myAddressInput.value) { // check if input is empty
            myAddressError.textContent = ""; // clear error message if input is empty
          }else if (myAddressInput.value.length < 4) {
         myAddressError.textContent = "Input must be at least 4 characters long";
        myAddressError.style.color = "red";
        } else {
          myAddressError.textContent = "";
         myAddressError.style.color = "initial";
        }
        });

        myIssueInput.addEventListener("input", function() {
          if (!myIssueInput.value) { // check if input is empty
            myIssueError.textContent = ""; // clear error message if input is empty
          }else if (myIssueInput.value.length < 5) {
         myIssueError.textContent = "Input must be at least 5 characters long";
        myIssueError.style.color = "red";
        } else {
          myIssueError.textContent = "";
         myIssueError.style.color = "initial";
        }
        });

      </script>
<!-- ------------------------ -->
       <script>
  const form = document.querySelector('form');
  const submitBtn = document.querySelector('#submit');

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(form);

    fetch(form.action, {
      method: form.method,
      body: formData
    })
    .then(response => {
      if (response.ok) {
        showToast('success', 'Data captured successfully');
        form.reset();
      } else {
        showToast('error', 'Error adding data');
      }
    })
    .catch(error => {
      showToast('error', 'Error adding data');
    });
  });

  function showToast(type, message) {
    const toast = document.createElement('div');
    toast.classList.add('toast', `toast-${type}`);
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3000);
  }
</script>
  </body>
</html>
