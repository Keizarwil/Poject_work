<?php
session_start();
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pdms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
if(isset($_POST['fname'])){
  $Firstname = $_POST['fname'];
  $Lastname = $_POST['lname'];
  $Contact = $_POST['contact'];
  $prescription = $_POST['prescription'];
  $username=$_SESSION['username'];

// Insert data into database
$sql = "INSERT INTO prescription (Firstname, Lastname, contact, prescription,prescribed_by) 
VALUES ('$Firstname', '$Lastname', '$Contact', '$prescription','$username')";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>patient details</title>
    
  </head>
  <body>
    <div class="people-icon">
        <img src="images/group.png" style="width:30px; margin-right: 10px;">
        <h3><b>Patients</b></h3>
        <button id="search" ><a href="ajax.php">Search</a></button> 
        <button id="my-prescription" ><a href="report.php">View prescriptions</a></button>
    </div>
    
	<div id="modal" >
  <div class="modal-content">
    <span class="close" onclick="hideModal()">&times;</span>
    <h2 style="Text-align:center">Add prescription</h2>
    <form id="update-form" method="post" action="retrieve.php">
      <label for="name"><b>Firstname:</b></label><br>
      <input type="text" name="fname" id="fname">
      <br>
      <label for="lname"><b>Lastname:</b></label><br>
      <input type="text" name="lname" id="lname" script="height:3px"><br>
      <label for="contact"><b>contact:</b></label><br>
      <input type="text" name="contact" id="contact"><br>
      <label for="prescription"><b>Prescription:</b></label><br>
      <input type="text" name="prescription" id="prescription"><br>
      
      <input type="submit" value="Save" id="submit" style="background-color:green; outline:none; border: none;
       color: white; padding:5px;border-radius:5px;cursor:pointer";>
    </form>
  </div>
</div>

<script>
    function showModal() {
  // Show the modal
  document.getElementById("modal").style.display = "block";
}

function hideModal() {
  // Hide the modal
  document.getElementById("modal").style.display = "none";
}

function submitForm(event) {
  // Prevent the default form submission behavior
  event.preventDefault();

  // Get the form data
  var formData = new FormData(document.getElementById("update-form"));

  // Create an XMLHttpRequest object
  var xhr = new XMLHttpRequest();

  // Define the function to be called when the response is received
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      // Get the response from the server
      var response = xhr.responseText;

      // Hide the modal
      hideModal();
    }
  };

  // Send a request to the PHP script to update the user information
  xhr.open("POST", "update.php", true);
  xhr.send(formData);
}

// Add an event listener to the form submit button
document.getElementById("update-form").addEventListener("submit", submitForm);

</script>
<script>
  const form = document.querySelector('form');
  const submitBtn = document.querySelector('#submit');

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(form);

    fetch(form.action, {
      method: form.method,
      body: formData
    })
    .then(response => {
      if (response.ok) {
        showToast('success', 'Data captured successfully');
        form.reset();
      } else {
        showToast('error', 'Error adding data');
      }
    })
    .catch(error => {
      showToast('error', 'Error adding data');
    });
  });

  function showToast(type, message) {
    const toast = document.createElement('div');
    toast.classList.add('toast', `toast-${type}`);
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3000);
  }
</script>

</body>
</html>

<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pdms";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Determine the total number of records
$sql = "SELECT COUNT(*) as total FROM patient";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$total_records = $row['total'];

// Define how many records to display per page
$records_per_page = 10;

// Calculate the total number of pages
$total_pages = ceil($total_records / $records_per_page);

// Determine the current page
if (!isset($_GET['page'])) {
    $current_page = 1;
} else {
    $current_page = $_GET['page'];
}

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $records_per_page;

// Retrieve data from database
$sql = "SELECT * FROM patient LIMIT $offset, $records_per_page";
$result = mysqli_query($conn, $sql);

// Create a table to display the data
if (mysqli_num_rows($result) > 0) {
 echo '<table class="table" style="border-radius:10px" id="table-body">
        <thead>
            <tr>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>contact</th>
                <th>Address</th>
                <th>issue</th>
                <th></th>
            </tr>
        </thead>
        <tbody>';

 // Loop through the results and display the data in the table

    while($row = mysqli_fetch_assoc($result)) {
        echo '<tr id="table-body">
                <td>' . $row["Firstname"] . '</td>
                <td>' . $row["Lastname"] . '</td>
                <td>' . $row["Gender"] . '</td>
                <td>' . $row["DOB"] . '</td>
                <td>' . $row["contact"] . '</td>
                <td>' . $row["Address"] . '</td>
                <td>' . $row["issue"] . '</td>
                <td ><Button style="background-color: #85C1E9; outline: none; border:none; 
                padding:5px;border-radius:5px;cursor:pointer" onclick="showModal()">View</Button></td>
            </tr>';
            
    }
    
  echo '</tbody></table>';

 // Display pagination links
 echo "<div class='pagination'>";
 if ($current_page > 1) {
    echo "<a href='?page=" . ($current_page - 1) . "' id='link-btn'>Prev</a>";
 }
 for ($i = 1; $i <= $total_pages; $i++) {
    if ($i == $current_page) {
        echo "<span>$i</span>";
    } else {
        echo "<a href='?page=$i'>$i</a>";
    }
 }
 if ($current_page < $total_pages) {
    echo "<a href='?page=" . ($current_page + 1) . "' id='link-btn'>Next</a>";
 }
 echo "</div>";
} else {
echo "0 results found";
}

// Close the database connection
mysqli_close($conn);
?>

<style>
    body{
        background-color: #D5D8DC ;
    }
   
    .table {
        font-family: Arial, sans-serif;
        border-collapse: collapse;
        width: 80%;
        margin-bottom: 20px;
        margin-left: 50px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.20);
    }
    
    .table th, .table td {
        /* border: 1px solid #ddd; */
        padding: 8px;
        text-align: left;
    }
    
    .table th {
        background-color: #99A3A4;
        
    }
    
    .table tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    
    .table tr:hover {
        background-color: #ddd;
    }
    h3{
        text-align: center; 
        font-size:20px;
    }
    .people-icon{
        display: flex;
        align-items: center;
        margin-left: 60px;
        padding-right: 5px;
    }
    #search{
      background-color: #5F6A6A;
      border: none;
      outline: none;
      cursor: pointer;
      padding: 5px;
      border-radius: 5px;
      margin-left: 500px;
    }
    #search a{
      color: white;
      text-decoration: none;
    }

    #my-prescription{
      background-color: #5F6A6A;
      border: none;
      outline: none;
      cursor: pointer;
      padding: 5px;
      border-radius: 5px;
      margin-right: 40px;
      margin-left: 40px;
    }
    #my-prescription a{
      color: white;
      text-decoration: none;
    }
    #link-btn{
      background-color: #85929E;
      text-decoration: none;
      color: #fff;
      padding: 7px;
      border-radius: 5px;
      cursor: pointer;
      margin-left: 30px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.16);
    }
    /* --------------- */
      .pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
}

.pagination a {
  display: inline-block;
  background-color: #717D7E;
  color: white;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  margin: 0 2px;
  border-radius: 3px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.16);
}

.pagination a:hover {
  background-color: #707B7C;
}

.pagination a.active {
  background-color: #003366;
}


    /* ---------------------- */
/* Style the modal background */
#modal {
  display: none;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.5);

}

/* Style the modal content */
.modal-content {
  background-color: white;
  margin: 10% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 50%;
  height: 60%;
  animation-name: slide-in;
  animation-duration: 0.5s;
  animation-fill-mode: forwards;
  transform: translateY(-100%);
  border-radius: 10px;
}
@keyframes slide-in {
  from {
    transform: translateY(-100%);
  }
  to {
    transform: translateY(0);
  }
}

/* Style the close button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
input[type="text"]
   {
    width: 60%;
    padding: 10px;
    margin-bottom: 20px;
    border: none;
    border-radius: 5px;
    box-shadow: 0 0 5px #ccc;
  }
  form{
    margin-left: 100px;
  }
  /* -------------------- */
  .toast {
    position: fixed;
    top: 10px;
    left: 50%;
    transform: translateX(-50%);
    padding: 10px 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    color: #fff;
    font-size: 14px;
    z-index: 9999;
    opacity: 0;
    animation: fadeIn 0.5s forwards, fadeOut 0.5s 2.5s forwards;
  }
  
  .toast-success {
    background-color: green;
  }
  
  .toast-error {
    background-color: red;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  @keyframes fadeOut {
    from { opacity: 1; }
    to { opacity: 0; }
  }
  
</style>
