<?php
session_start();
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pdms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
if(isset($_POST['fname'])){
  $Firstname = $_POST['fname'];
  $Lastname = $_POST['lname'];
  $Contact = $_POST['contact'];
  $prescription = $_POST['prescription'];
  $username=$_SESSION['username'];
  



// Insert data into database
$sql = "INSERT INTO prescription (Firstname, Lastname, contact, prescription,prescribed_by) 
VALUES ('$Firstname', '$Lastname', '$Contact', '$prescription','$username')";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>