<?php
// Retrieve the record ID from the POST parameters
$id = $_POST['ID'];
$checked = $_POST['checked'];


// Connect to the MySQL database
$conn = mysqli_connect('localhost', 'root', "", 'pdms');
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
  }

$sql = "UPDATE prescription SET cleared = ";
if ($checked == 'true') {
  $sql .= "true";
} else {
  $sql .= "false";
}
$sql .= " WHERE ID = " . $id;

$result = mysqli_query($conn, $sql);

// Close the database connection
mysqli_close($conn);

// Send a response back to the client
if ($result) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}
?>
