<?php
// Establish database connection
$conn = mysqli_connect("localhost", "root", "", "pdms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle DELETE request
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = $_REQUEST['id'];
    $sql = "DELETE FROM patient WHERE ID = '$id'";

    if (mysqli_query($conn, $sql)) {
        http_response_code(204); // success, no content
        
    } else {
        http_response_code(500); // internal server error
        echo "Error deleting record: " . mysqli_error($conn);
    }
}

// Close database connection
mysqli_close($conn);
?>
