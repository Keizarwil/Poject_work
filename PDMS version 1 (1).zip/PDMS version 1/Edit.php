<?php  
 $connect = mysqli_connect("localhost", "root", "", "pdms");  
 $query = "SELECT * FROM patient ORDER BY ID DESC";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Patient Details</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>   
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />   
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>   
      </head>  
      <body>  
           <br /><br />  
           <div class="container" style="width:100%;">
           <div style="display:flex;">  
           <img src="images/group.png" style="width:30px;height:30px; margin-right: 20px;margin-left:50px;margin-top:10px">
                <h3 align="center">Patient Records</h3>  
           </div>
                <br />  
                <div class="table-responsive">  
                      <div id="employee_table" style="width:100%">  
                          <table class="table table-bordered"  >  
                               <tr>  
                                    <th >First Name</th>  
                                   <th >Last Name</th>  
                                   <th >contact</th> 
                                   <th >Address</th> 
                                   <th >issue</th> 
                                   <th ></th>
                                   <th></th>
                               </tr>  
                               <?php  
                               while($row = mysqli_fetch_array($result))  
                               {  
                               ?>  
                               <tr>  
                                    <td><?php echo $row["Firstname"]; ?></td>  
                                    <td><?php echo $row["Lastname"]; ?></td>
                                    <td><?php echo $row["contact"]; ?></td>
                                    <td><?php echo $row["Address"]; ?></td>
                                    <td><?php echo $row["issue"]; ?></td>
                                    <td><input type="button" name="edit"  value="Edit" id="<?php echo $row["ID"];?>" class="btn btn-info btn-xs edit_data" /></td>
                                    <td><button class='delete-btn' data-id="<?php echo $row["ID"];?>">Delete</button></td>  
                                     
                               </tr>  
                               <?php  
                               }  
                               ?>  
                          </table>  
                     </div>  
                </div>  
           </div>  
      </body>  
 </html>  
 <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Patient Details</h4>  
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Edit patient Details</h4>  
                </div>  
                <div class="modal-body">  
                     <form method="post" id="insert_form">  
                          <label>Enter FirstName</label>  
                          <input type="text" name="name" id="name" class="form-control" />  
                          <br />  
                          <label>Enter Lastname</label>  
                          <textarea name="address" id="address" class="form-control"></textarea>  
                          <br />  
                          <label>Select Gender</label>  
                          <select name="gender" id="gender" class="form-control">  
                               <option value="Male">Male</option>  
                               <option value="Female">Female</option>  
                          </select>  
                          <br />  
                          <label>Enter Address</label>  
                          <input type="text" name="designation" id="designation" class="form-control" />  
                          <br />  
                          <label>Enter issue</label>  
                          <input type="text" name="age" id="age" class="form-control" />  
                          <br />  
                          <input type="hidden" name="employee_id" id="employee_id" />  
                          <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />  
                     </form>  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <script>  
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      });  
      $(document).on('click', '.edit_data', function(){  
           var employee_id = $(this).attr("id");  
           $.ajax({  
                url:"fetch.php",  
                method:"POST",  
                data:{employee_id:employee_id},  
                dataType:"json",  
                success:function(data){  
                     $('#name').val(data.Firstname);  
                     $('#address').val(data.Lastname);  
                     $('#gender').val(data.Gender);  
                     $('#designation').val(data.Address);  
                     $('#age').val(data.issue);  
                     $('#employee_id').val(data.ID);  
                     $('#insert').val("Update");  
                     $('#add_data_Modal').modal('show');  
                }  
           });  
      });  
      $('#insert_form').on("submit", function(event){  
           event.preventDefault();  
           if($('#name').val() == "")  
           {  
                alert("FirstName is required");  
           }  
           else if($('#address').val() == '')  
           {  
                alert("Lastname is required");  
           }  
           else if($('#designation').val() == '')  
           {  
                alert("Address is required");  
           }  
           else if($('#age').val() == '')  
           {  
                alert("issue is required");  
           }  
           else  
           {  
                $.ajax({  
                     url:"insert.php",  
                     method:"POST",  
                     data:$('#insert_form').serialize(),  
                     beforeSend:function(){  
                          $('#insert').val("Inserting");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#add_data_Modal').modal('hide');  
                          $('#employee_table').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"select.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>
 <script>
// Add event listeners to all delete buttons
var deleteBtns = document.querySelectorAll('.delete-btn');
deleteBtns.forEach(function(btn) {
    btn.addEventListener('click', function(event) {
        var id = btn.getAttribute('data-id');
        var xhr = new XMLHttpRequest();
        xhr.open('DELETE', 'delete.php?id=' + id, true);
        xhr.onload = function() {
            if (xhr.status === 204) {
                // Reload the page to show updated data
                location.reload();
            } else {
                // Handle error
                console.log('Error deleting record: ' + xhr.statusText);
            }
        };
        xhr.send();
    });
});
</script>

</scrip>
 <style>
    body{
        background-color: #D5D8DC ;
    }
   
    .table {
        font-family: Arial, sans-serif;
        border-collapse: collapse;
        width: 80%;
        margin-bottom: 20px;
        margin-left: 50px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15); 
    }
    
    .table th, .table td {
        /* border: 1px solid #ddd; */
        padding: 8px;
        text-align: left;
    }
    
    .table th {
        background-color: #99A3A4;
        
    }
    
    .table tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    
    .table tr:hover {
        background-color: #ddd;
    }
    h3{
        text-align: center; 
        font-size:20px;
    }
    .delete-btn{
     background-color: #EC7063;
     color: white;
     border:none;
     outline:none;
     border-radius:5px;
     padding:2px;
    }
    </style>
 