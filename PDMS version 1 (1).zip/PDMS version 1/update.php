<?php

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pdms";
$conn = new mysqli($servername, $username, $password, $dbname);

if(ISSET($_POST['update'])){
    $contact = $_POST['contact'];
    $firstname = $_POST['Firstname'];
    $lastname = $_POST['Lastname'];
    
    
    mysqli_query($conn, "UPDATE `patient` SET `Firstname` = '$firstname', `Lastname` = '$lastname' WHERE `contact` = '$contact'");

    header("location: Edit.php");
}
// Check connection



?>