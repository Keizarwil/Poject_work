<?php
// Connect to MySQL database
$host = "localhost"; //database host
$username = "root"; // database username
$password = ""; // database passwd
$dbname = "pdms"; // database name

$conn = mysqli_connect($host, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// Get user input
$username = $_POST['username'];
$password = $_POST ['password'];
$input_password_md5 = md5($password);

// Query database for matching username and password
$sql = "SELECT * FROM users WHERE username='$username' AND password='$input_password_md5'";
$result = mysqli_query($conn, $sql);

// Check if query returned a row
if (mysqli_num_rows($result) > 0) {
  $row=$result->fetch_assoc();
   // Start a session to store the login status
     session_start();
     $_SESSION['logged_in'] = true;
     $_SESSION['username']="$username";
    $_SESSION['role']=$row['role'];
    if($row['role']==='admin'){
      header('Location:data.php');
    }else if($row['role']==='pharmacist'){
      header('Location:pharmacy.php');
    }else{
      header('Location:medical.php');
    }
     
    exit;
} else {
    
    // Show an error message
      $_SESSION['error'] = 'invalid username or password';

    // // Redirect the user back to the login page
     header('Location: login.php');
     exit;
}
}
 if (isset($_SESSION['error'])) {
   // Show the error message using JavaScript
   echo '<script>alert("' . $_SESSION['error'] . '")</script>';

  // Remove the error message from the session
  unset($_SESSION['error']);
 }

// Close database connection
mysqli_close($conn);

?>
<html>
    <head>
        <Title>Login</Title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="shortcut icon" href="favicon/one.ico" type="favicon/x-icon">
    </head>
    
    <body>
        <h1>INSTA-HEALTH PDMS</h1>
<form action="login.php" method="post" id="form">
    <img src="images/icon.png" alt="user_icon">
  <input type="text" id="username1" name="username" placeholder="Username">
  <input type="password" id="password1" name="password" placeholder="Password">
  <input type="submit" value="Login" onclick="checkLogin()">
</form>
</body>
</html>