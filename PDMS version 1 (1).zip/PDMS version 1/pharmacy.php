<?php
// Start the session
session_start();

//Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page
   header("Location: login.php");
    exit();
}
if ($_SESSION['role']!=='pharmacist') {
  // Redirect to the login page
  header("Location: login.php");
  exit();
}
?> 
<html>
  <head>
  <link rel="shortcut icon" href="favicon/one.ico" type="favicon/x-icon">
  <title>Pharmacy</title>
  </head>
</html>
<?php
//connection to database
$conn=new mysqli('localhost','root',"",'pdms');
if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

// Determine the total number of records
$sql = "SELECT COUNT(*) as total FROM prescription";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$total_records = $row['total'];

// Define how many records to display per page
$records_per_page = 10;

// Calculate the total number of pages
$total_pages = ceil($total_records / $records_per_page);

// Determine the current page
if (!isset($_GET['page'])) {
    $current_page = 1;
} else {
    $current_page = $_GET['page'];
}

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $records_per_page;

// Retrieve data from database
$sql = "SELECT * FROM prescription LIMIT $offset, $records_per_page";
$result = mysqli_query($conn, $sql);



echo '<head>
      <style>
      /* Style the checkbox */
      input[type="checkbox"] {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        width: 20px;
        height: 20px;
        border: 2px solid #ddd;
        border-radius: 4px;
        outline: none;
        transition: all 0.3s ease-in-out;
        position: relative;
        margin: 0;
        cursor: pointer;
      }
      
      /* Style the checkbox when checked */
      input[type="checkbox"]:checked::before {
        content: "\2713"; /* Unicode checkmark character */
        display: block;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: #4caf50; /* Green color */
        font-size: 16px;
      }
      
      /* Style the checkbox when focused */
      input[type="checkbox"]:focus {
        box-shadow: 0 0 5px #ddd;
      }
      
      /* Style the checkbox when hovered */
      input[type="checkbox"]:hover:not(:checked) {
        border-color: #aaa;
      }
      
      /* Hide the checkbox visually */
      input[type="checkbox"] + label:before {
        content: "";
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 2px solid #ddd;
        border-radius: 4px;
        margin-right: 8px;
        vertical-align: middle;
      }
      
      /* Hide the checkbox visually when checked */
      input[type="checkbox"]:checked + label:before {
        background-color: #4caf50;
        border-color: #4caf50;
      }
      

</style>
</head>';

echo '<button id="logoutBtn">Logout<img src="images/logout.png" id="img"></button>';
echo "<div style='display:flex'>";
echo "
<div class='sidenav'>
<ul>
 <li><img src='images/drugs.png' style='width:20px;padding-right:5px'>
 <a href='pharmacy.php' style='text-decoration:none;color:white'>Prescriptions</a></li>
 </ul>
 </div>
";
echo "</div>";
// Create a table to display the data
if (mysqli_num_rows($result) > 0) {
  
 echo '<table class="table" style="border-radius:10px">
        <thead>
            <tr>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>contact</th>
                <th>prescription</th>
                <th>date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>';

 // Loop through the results and display the data in the table

    while($row = mysqli_fetch_assoc($result)) {
      $checkboxId = $row['ID'];
      $checkboxName = "my_checkbox_$checkboxId";
      $isChecked = $row['cleared'] == 1;
      echo '<tr>
                <td>' . $row["Firstname"] . '</td>
                <td>' . $row["Lastname"] . '</td>
                <td>' . $row["contact"] . '</td>
                <td>' . $row["prescription"] . '</td>
                <td>' . $row["date"] . '</td>
                <td data-id="' . $row['ID'] . '">' .'<input type="checkbox" name="$checkboxName" id="$checkboxId" ' . ($isChecked ? 'checked' : '') .'  onchange="clearRecord(' . $row['ID'] . ', this.checked)">'.'</td>
            </tr>';
            
    }
    
  echo '</tbody></table>';
echo "</div>";



echo '<script>
function clearRecord(ID, checked) {
  // Send an HTTP request to update the database
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "update_record.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      // If the update was successful, update the UI
      var td = document.querySelector(\'td[data-id="\' + ID + \'"]\');
      var checkbox = td.querySelector(\'input[type="checkbox"]\');
      checkbox.checked = checked;
    }
  };
  xhr.send("ID=" + ID + "&checked=" + checked);
};

document.getElementById("logoutBtn").addEventListener("click", function() {
    // clear session data and redirect to login page
    sessionStorage.clear();
    window.location.href = "logout.php";
    
  });

</script>';



 // Display pagination links
 echo "<div class='pagination'>";
 if ($current_page > 1) {
    echo "<a href='?page=" . ($current_page - 1) . "' id='link-btn'>Prev</a>";
 }
 for ($i = 1; $i <= $total_pages; $i++) {
    if ($i == $current_page) {
        echo "<span>$i</span>";
    } else {
        echo "<a href='?page=$i'>$i</a>";
    }
 }
 if ($current_page < $total_pages) {
    echo "<a href='?page=" . ($current_page + 1) . "' id='link-btn'>Next</a>";
 }
 echo "</div>";
} else {
echo "0 results found";
}

// Close the database connection
mysqli_close($conn);
?>

<style>
    body{
        background-color: #D5D8DC ;
        
    }
   
    .table {
        font-family: Arial, sans-serif;
        border-collapse: collapse;
        width: 80%;
        margin-bottom: 20px;
         margin-left: /*50px*/200px; 
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.20);
        align-items: center;
        border-top-right-radius: 10px;
        position: relative;

    }
    
    .table th, .table td {
        
        padding: 8px;
        text-align: left;
    }
    
    .table th {
        background-color: #0B5345;
        color:#fff
        
    }
    
    .table tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    
    .table tr:hover {
        background-color: #ddd;
    }
    h3{
        text-align: center; 
        font-size:20px;
    }
   
    #link-btn{
      background-color: #85929E;
      text-decoration: none;
      color: #fff;
      padding: 7px;
      border-radius: 5px;
      cursor: pointer;
      margin-left: 30px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.16);
    }
    /* --------------- */
      .pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
}

.pagination a {
  display: inline-block;
  background-color: #717D7E;
  color: white;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  margin: 0 2px;
  border-radius: 3px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.16);
}

.pagination a:hover {
  background-color: #707B7C;
}

.pagination a.active {
  background-color: #003366;
}

#logoutBtn{
    background-color: #581845;
    padding: 5px;
    display: flex;
    cursor: pointer;
    border-radius: 5px;
    color: #fff;
    border: none;
    outline: none;
    margin-left: 79em;
    margin-bottom: 5px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.20); 
     transform: translate3d(0, -2px, 0);
    transition: transform 0.2s ease-in-out;
    transform-style: preserve-3d;
    transform: translateZ(70px);
    perspective: 200px;
}
#logoutBtn:hover{
  transform: translate3d(0, -5px, 0);
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.20);
}
#logoutBtn #img{
    padding-left: 5px;
    
}

.sidenav{
  background-color: #99A3A4;
  height: 90%;
  width: 180px;
  position: absolute;
  border-radius: 5px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.20);
}
.sidenav ul{
  padding-left: 10px;
  padding-right: 10px;
  
}
.sidenav ul li{
  color: #fff;
  margin-bottom: 10px;
  list-style: none;
  background-color: #581845;
  padding: 10px;
  border-radius: 5px;
  cursor: pointer;
  padding-left: 7px;
  text-align: center;
  transform: translate3d(0, -2px, 0);
  transition: transform 0.2s ease-in-out;
  display: flex;
}
.sidenav ul li:hover{
  transform: translate3d(0, -5px, 0);
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.20);
}

</style>
