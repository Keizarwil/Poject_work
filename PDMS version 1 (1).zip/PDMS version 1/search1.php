
<?php
// Get the search terms from the AJAX request
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pdms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Construct the SQL query to search the table for matching records
$sql = "SELECT * FROM patient WHERE Firstname LIKE '%" . $first_name . "%' AND Lastname LIKE '%" . $last_name . "%'";

// Execute the query and fetch the results
$result = $conn->query($sql);

// Check if any records were found
if ($result->num_rows > 0) {
    // Display the results in a table
    echo "<table>";
    echo "<tr>
<th>First Name</th>
<th>Last Name</th>
<th>Gender</th>
<th>DOB</th>
<th>Contact</th>
<th>Address</th>
<th>Issue</th>
<th></th>
</tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["Firstname"] . "</td>
        <td>" . $row["Lastname"] . "</td>
        <td>" . $row["Gender"] . "</td>
        <td>" . $row["DOB"] . "</td>
        <td>" . $row["contact"] . "</td>
        <td>" . $row["Address"] . "</td>
        <td>" . $row["issue"] . "</td>
        <td ><Button style='background-color: #85C1E9; outline: none; border:none; 
        padding:5px;border-radius:5px;cursor:pointer' onclick='showModal()'>View</Button></td>
        </tr>";
    }
    echo "</table>";
} else {
    // Display a message if no records were found
    echo "<p class='no-results'>No matching records found.</p>";
}

// Close the database connection
$conn->close();
?>
