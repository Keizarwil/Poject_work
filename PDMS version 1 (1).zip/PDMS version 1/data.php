 <?php

// Start the session
session_start();

//Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page
    header("Location: login.php");
    exit();
}
if ($_SESSION['role']!=='admin') {
  // Redirect to the login page
  header("Location: login.php");
  exit();
}
?> 

<?php
if (isset($_POST['logout'])) { // check if the logout button is pressed
  // Unset all session variables
 $_SESSION = array();

  // Destroy the session
  session_destroy();

  // Redirect to the login page or homepage
  header("Location: login.php");
  exit();
}
?>

<html>
    <head>
        <title>patient data</title>
        <link rel="stylesheet" text="style/css" href="wow.css">
	<link rel="shortcut icon" href="favicon/one.ico" type="favicon/x-icon">
        <script>
      function loadPage(url) {
        document.getElementById("rightPane").src = url;
      }
    </script>
    
    </head>
   
  <body>
  

    <div style="float:left; width:12%; background-color: #99A3A4; margin-top:0;position:fixed" class="links">
    <div id="logo">
    <img src="images/stethoscope.png" style="height:50px; margin-top:11px"> 
    <h3 style="color:white;Text-align:center; padding: 10px 0 5px 10;"><b>Insta<span>Health</span></b></h3></div>
    
      <a href="#" onclick="loadPage('data entry.php');" id="one" >Data Entry</a><br><br><br>
      
      <a href="#" onclick="loadPage('Edit.php');" id="two">View patient Details</a><br><br><br>

 <form action="data.php" method="POST">
  <button type="submit"name="logout" id="logout" style="background-color: #581845;
   margin-top: 29em; padding:10px; border-radius:5px; border:none; 
   color:white; margin-left:30px; cursor:pointer; flex-wrap:wrap-reverse">Logout</button> 
  </form>

  </div>
    <div style="float:right; width:80%; min-height: 100vh" class="data">
      <iframe id="rightPane" src="data entry.php" style="width:100%; height:120%; border:0px;border-radius:10px" ></iframe>
      
    </div>
  </body>
</html>